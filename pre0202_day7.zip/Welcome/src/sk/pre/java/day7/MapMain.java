package sk.pre.java.day7;

public class MapMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MapMain mm = new MapMain();
		//mm.test();
		mm.testCal();
	}
	public void testCal() {
		TestCalendar cal = new TestCalendar();
		cal.test1();
	}
	public void test() {
		MapTest mt = new MapTest();
		mt.test1();
	}

}
