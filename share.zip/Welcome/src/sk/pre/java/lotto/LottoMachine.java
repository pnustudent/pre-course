package sk.pre.java.lotto;

public class LottoMachine {
	private LottoBall[] balls;
	
	
	public void setBalls(LottoBall[] balls) {
		this.balls = balls;
	}
	
//	public LottoBall[] getBalls() {
//		return balls;
//	}
	
	//볼을 뽑는 행동
	public void selectBalls() {
		//공을 섞는 과정 ->하나의 메소드
		//공을 하나 뽑는 과정 -> 하나의 메소드
		//뽑은 공의 중복을 처리해야 함 -> 여기서 처리
	}
	
	
	
}
