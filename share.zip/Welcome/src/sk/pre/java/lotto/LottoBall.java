package sk.pre.java.lotto;

public class LottoBall {
	private int number;
	public LottoBall(int number) {
		this.number = number;
	}
	
	public int getNumber() {
		return number;
	}
	
//	public void setNumber(int number) {
//		this.number = number;
//	}
	
}
