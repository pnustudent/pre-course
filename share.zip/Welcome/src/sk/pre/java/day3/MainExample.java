package sk.pre.java.day3;

public class MainExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
