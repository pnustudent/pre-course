package sk.pre.java.day3;

public class Student extends Person{
	private String major;
	public Student(String major) {
		//super("kim");
		this.major = major;
	}
}
