package sk.pre.java.day6;

public class CollenctionMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CollenctionMain cm = new CollenctionMain();
		cm.testList();
	}
	
	public void testList() {
		CollectionTest test = new CollectionTest();
		test.testArrayList();
	}

}
