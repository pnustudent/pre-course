package sk.pre.java.day1;

public class HelloSKU {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello");
	}

}
