package sk.pre.java.day6;

import java.util.Arrays;
import java.util.Random;

public class LottoMachine {
	private LottoBall[] balls;
	
	public void setBalls(LottoBall[] balls) {
		this.balls = balls;
	}
	
	public void startMachine() {
		this.selectBalls();
	}
	
	private void selectBalls() {
		LottoBall[] selectedBalls = new LottoBall[6];
		LottoBall ball = null;
		for(int i=0;i<6;i++) {
			ball = this.getBall();
			if(ball.isSelected()) {
				i = i - 1;
			} else {
				ball.setSelected(true);
				selectedBalls[i] = ball;
			}
		}
		this.printBalls(selectedBalls);
	}
	
	private LottoBall getBall() {
		Random r = new Random();
		int index = r.nextInt(45);
		
		return balls[index];
	}
	
	private void printBalls(LottoBall[] balls) {
		System.out.println(Arrays.toString(balls));
	}
}







