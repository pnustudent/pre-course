package sk.pre.java.day9;

public class MainDay9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MainDay9 day9 = new MainDay9();
		day9.test();
	}
	
	public void test() {
		TestThread tt = new TestThread();
		tt.test4();
	}

}
