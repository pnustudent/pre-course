package sk.pre.java.day3;

public class Person {
	private String name;
	private int age;
	public Person() {}
	public Person(String name) {
		this.name = name;
	}
}
