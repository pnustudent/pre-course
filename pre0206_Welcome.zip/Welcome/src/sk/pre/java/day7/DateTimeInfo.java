package sk.pre.java.day7;

public enum DateTimeInfo {
	FULL_DATE_TIME,DATE_ONLY,TIME_ONLY
}
