package sk.pre.java.day5;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main main = new Main();
		main.start();
	}
	public void start() {
		Service service = new Service();
		service.test6();
	}

}
